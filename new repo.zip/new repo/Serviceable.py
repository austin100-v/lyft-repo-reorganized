from abc import ABC, abstract method

class Serviceable(ABC):
    @abstractmethod 
    def needs_service(self) -> bool:
        pass
        

        

