from Serviceable import Serviceable

from abc import ABC, abstractmethod

class Car(Serviceable, ABC):
    def __init__(self, battery:Battery, engine:Engine):
        self.battery = battery
        self.engine = engine
    
    @abstractmethod
    def needs_service(self):
        pass